package client

type Client struct {
	ID       string
	Username string
	Level    int
}
