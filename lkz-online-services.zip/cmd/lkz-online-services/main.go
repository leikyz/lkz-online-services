package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"time"

	"github.com/leikyz/lkz-online-services/internal/network"
)

var cppConn net.Conn

// InitCppConnection avec une logique de retry
func InitCppConnection() {
	var err error
	for i := 0; i < 5; i++ { // Tente 5 fois
		cppConn, err = net.Dial("tcp", "127.0.0.1:8081")
		if err == nil {
			fmt.Println("Connecté au serveur C++ sur le port 8081 ✅")
			return
		}
		fmt.Printf("Tentative de connexion C++ échouée (%d/5), nouvel essai dans 2s...\n", i+1)
		time.Sleep(2 * time.Second)
	}
	log.Fatalf("Échec définitif de connexion au serveur C++: %v", err)
}

func main() {
	// Lancer la connexion C++
	InitCppConnection()
	defer cppConn.Close()

	mux := http.NewServeMux()
	network.RegisterHandlers(mux)

	fmt.Println("LKZ Online Services Starting on :8080... 🚀")

	// Utilisation de ListenAndServeTLS comme tu l'as prévu
	log.Fatal(http.ListenAndServeTLS(":8080", ".local/certs/cert.crt", ".local/certs/cert.key", mux))
}
